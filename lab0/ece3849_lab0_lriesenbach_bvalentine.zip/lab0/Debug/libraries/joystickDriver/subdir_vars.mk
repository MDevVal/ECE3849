################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
C:/Users/Leo\ Riesenbach/Downloads/Lab_0/libraries/joystickDriver/joystick.cpp 

OBJS += \
./libraries/joystickDriver/joystick.obj 

CPP_DEPS += \
./libraries/joystickDriver/joystick.d 

OBJS__QUOTED += \
"libraries\joystickDriver\joystick.obj" 

CPP_DEPS__QUOTED += \
"libraries\joystickDriver\joystick.d" 

CPP_SRCS__QUOTED += \
"C:/Users/Leo Riesenbach/Downloads/Lab_0/libraries/joystickDriver/joystick.cpp" 


